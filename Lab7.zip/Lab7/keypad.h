#include "stm32l476xx.h"
#include <stdint.h>


unsigned char keypad_scan();
void keypad_pin_init();